<div class="card mt-4">
    <div class="card-header">
        <a href="user.php" class="btn btn-info btn-icon-split">
            <span class="icon text-white">
                <i class="fa fa-arrow-circle-left"></i> kembali
            </span>
        </a>
    </div>

    <div class="card-body">
        <table class="table table-striped table-hover table-responsive align-bottom" id="table">
            <h3>Catatan Perjalanan</h3>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tangal</th>
                    <th>jam</th>
                    <th>lokasi</th>
                    <th>Suhu Tubuh</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>No</th>
                    <th>Tangal</th>
                    <th>jam</th>
                    <th>lokasi</th>
                    <th>Suhu Tubuh</th>
                </tr>
            </tfoot>
            <tbody>
                <?php
                $no = 1;
                $data = file('catatan.txt', FILE_IGNORE_NEW_LINES);
                $user = $_SESSION['nik'] . "|" . $_SESSION['nama_lengkap'];
                foreach ($data as $value) :
                    $pecah = explode("|", $value);
                    $key = $pecah['0'] . "|" . $pecah['1'];
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $pecah['2']; ?></td>
                        <td><?= $pecah['3']; ?></td>
                        <td><?= $pecah['4']; ?></td>
                        <td><?= $pecah['5']; ?>&deg; C</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>

        </table>

    </div>
</div>
