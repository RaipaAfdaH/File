<?php

session_start();
if (empty($_SESSION['nik'])) {
  echo '<script>alert("Silahkan Login")
  document.location.href = "index.php";
  </script>';

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="fontawesome/css/all.min.css" />

  <link rel="stylesheet" href="DataTables/DataTables-1.11.4/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="DataTables/Buttons-2.2.2/css/buttons.bootstrap5.min.css">

  <?php if ($_GET['url'] == 'home') :?>
    <title>Peduli Diri</title>
  <?php elseif ($_GET['url'] == 'catatan_perjalanan') :?>
    <title>Catatan Perjalanan</title>
  <?php elseif ($_GET['url'] == 'tulis_catatan') :?>
    <title>Tulis Catatn</title>

  <?php endif; ?>

</head>
<body>
  <!-- bagian navbar -->
  <nav class="navbar navbar-expand-md navbar-dark bg-info">
    <div class="container">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <?php if (!$_GET['url']) : ?>

           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="?url=home">Home</a>
           </li>

           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="?url=tulis_catatan">Tulis Catatan</a>
           </li>

           <li class="nav-item">
             <a class="nav-link active" aria-current="page" href="?url=catatan_perjalanan">Catatan Perjalanan</a>
           </li>


         <?php else: ?>

          <?php if ($_GET['url'] == 'home') : ?>
            <li class="nav-item mx-2">
              <a href="?url=home" class="btn btn-info btn-icon-split nav-link active">
                <span class="icon text-white">
                  <i class="fas fa-home-alt"></i> Home
                </span>
              </a>
            </li>
          <?php else : ?>
            <li class="nav-item mx-2">
              <a href="?url=home" class="btn btn-info btn-icon-split nav-link">
                <span class="icon text-white">
                  <i class="fas fa-home-alt"></i> Home
                </span>
              </a>
            </li>

          <?php endif; ?>

          <?php if ($_GET['url'] == 'tulis_catatan') : ?>
            <li class="nav-item mx-2">
              <a href="?url=tulis_catatan" class="btn btn-info btn-icon-split nav-link active">
                <span class="icon text-white">
                  <i class="fas fa-edit"></i> Tulis Catatan
                </span>
              </a>
            </li>
          <?php else : ?>
            <li class="nav-item mx-2">
              <a href="?url=tulis_catatan" class="btn btn-info btn-icon-split nav-link ">
                <span class="icon text-white">
                  <i class="fas fa-edit"></i> Tulis Catatan
                </span>
              </a>
            </li>

          <?php endif; ?>

          <?php if ($_GET['url'] == 'catatan_perjalanan') : ?>
           <li class="nav-item mx-2">
            <a href="?url=catatan_perjalanan" class="btn btn-info btn-icon-split nav-link active">
              <span class="icon text-white">
                <i class="fas fa-book-reader"></i> Catatan Perjalanan
              </span>
            </a>
          </li>
        <?php else : ?>
          <li class="nav-item mx-2">
            <a href="?url=catatan_perjalanan" class="btn btn-info btn-icon-split nav-link">
              <span class="icon text-white">
                <i class="fas fa-book-reader"></i> Catatan Perjalanan
              </span>
            </a>
          </li>
        <?php endif; ?>

      <?php endif; ?>


    </ul>


  </div>

  <a href="logout.php" class="btn btn-info btn-icon-split">
    <span class="icon text-white">
      <i class="fa fa-sign-out-alt"></i> keluar
    </span>
  </a>
</div>
</nav>
<!-- akhir navbar -->

<div class="container mt-2">
  <div class="h4 mb-4 text-gray-800">
    <?php
    if (!empty(@$_GET['url'])) {
      switch (@$_GET['url']) {
        case 'home';
        include 'home.php';
        break;
        case 'tulis_catatan';
        include 'tulis_catatan.php';
        break;
        case 'catatan_perjalanan';
        include 'catatan_perjalanan.php';
        break;

        default:
        echo '<h3>Tidak ada halaman</h3>';
        break;
      }
    } else {
      header('location:user.php?url=home');
    }
    ?>
  </div>

</div>







<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.bundle.js"> </script>

<script src="DataTables/DataTables-1.11.4/js/jquery.dataTables.min.js
"></script>

<script src="DataTables/DataTables-1.11.4/js/dataTables.bootstrap5.min.js
"></script>

<script src="DataTables/Buttons-2.2.2/js/dataTables.buttons.min.js
"></script>
<script src="DataTables/Buttons-2.2.2/js/buttons.bootstrap5.min.js
"></script>
<script src="DataTables/JSZip-2.5.0/jszip.min.js"></script>
<script src="DataTables/pdfmake-0.1.36/pdfmake.min.js
"></script>
<script src="DataTables/pdfmake-0.1.36/vfs_fonts.js
"></script>
<script src="DataTables/Buttons-2.2.2/js/buttons.html5.min.js
"></script>
<script src="DataTables/Buttons-2.2.2/js/buttons.print.min.js
"></script>
<script src="DataTables/Buttons-2.2.2/js/buttons.colVis.min.js
"></script>

<script>
  $(document).ready(function() {
    var table = $('#table').DataTable( {
      lengthChange: false,
      buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    } );

    table.buttons().container()
    .appendTo( '#table_wrapper .col-md-6:eq(0)' );
  } );
</script>
</body>
</html>
