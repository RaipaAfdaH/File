<div class="card mt-4">
    <div class="card-header">
        <a href="user.php" class="btn btn-primary btn-icon-split">
            <span class="icon text-white">
                <i class="fa fa-arrow-circle-left"></i> kembali
            </span>
        </a>
    </div>

    <div class="card-body">
        <form method="post" action="simpan_catatan.php">
            <div class="form-group">
                <label for="tanggal" class="h5">Pilih Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" placeholder="Massukan Tanggal">
            </div>
            <div class="form-group">
                <label for="jam" class="h5">Waktu</label>
                <input type="time" name="jam" id="jam" class="form-control" placeholder="Massukan jam">
            </div>
            <div class="form-group">
                <label for="lokasi" class="h5">Pilih Lokasi</label>
                <input type="text" name="lokasi" id="lokasi" class="form-control" placeholder="Massukan lokasi">
            </div>
            <div class="form-group">
                <label for="suhu_tubuh" class="h5">Suhu Tubuh</label>
                <input type="text" name="suhu_tubuh" id="suhu_tubuh" class="form-control" placeholder="Masukan Hanya Angka ">
            </div>
            <hr>
            <div class="form-group mt-2">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> simpan</button>
                <button type="reset" class="btn btn-warning"><i class="fa fa-trash"></i> kosongkan</button>
            </div>
        </form>

    </div>
</div>