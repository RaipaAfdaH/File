<?php

$nik = $_POST['nik'];
$nama_lengkap = $_POST['nama_lengkap'];


// cek apakah nik sudah terdaftar atau belum

$data = file('config.txt', FILE_IGNORE_NEW_LINES);

foreach ($data as  $value) :
    $pecah = explode("|", $value);
    if ($nik == $pecah['0']) :
        echo '<script>alert("NIK Sudah Terdaftar")
                    document.location.href = "register.php";
                </script>';
        die;
    endif;
endforeach;

// cek apakah  nik sudah terdaftar atau belum
//jika tidak ada data
// buat format penyimpananke file txt config
$format = "\n$nik|$nama_lengkap";

// membuka file config
$file = fopen('config.txt', 'a');
fwrite($file, $format);

fclose($file);
?>
<script type="text/javascript">
    alert('Pendaftaran Berhasil');
    window.location.assign('index.php');
</script>