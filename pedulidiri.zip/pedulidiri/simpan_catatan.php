<?php

session_start();
$nik = $_SESSION['nik'];
$nama_lengkap = $_SESSION['nama_lengkap'];

$tanggal = $_POST['tanggal'];
$jam = $_POST['jam'];
$lokasi = $_POST['lokasi'];
$suhu_tubuh = $_POST['suhu_tubuh'];

$format = "\n$nik|$nama_lengkap|$tanggal|$jam|$lokasi|$suhu_tubuh";

// buka file catatan txt
$file = fopen('catatan.txt', 'a');
fwrite($file, $format);

fclose($file);
echo '<script>alert("Data Berhasil disimpan")
document.location.href = "user.php";
</script>';
